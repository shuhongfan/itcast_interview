package com.itheima.interceptor;

public class MyInterceptor {
}
