package com.itheima.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itheima.pojo.Account;
import org.apache.ibatis.annotations.*;

@Mapper
public interface AccountMapper extends BaseMapper<Account> {

}
