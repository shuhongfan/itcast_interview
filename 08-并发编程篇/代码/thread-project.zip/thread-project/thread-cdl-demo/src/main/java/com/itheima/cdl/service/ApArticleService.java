package com.itheima.cdl.service;

public interface ApArticleService {

    /**
     * 批量导入
     */
    public void importAll();
}
