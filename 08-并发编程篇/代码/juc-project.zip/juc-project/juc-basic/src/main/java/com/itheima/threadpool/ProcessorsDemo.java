package com.itheima.threadpool;

public class ProcessorsDemo {

    public static void main(String[] args) {
        System.out.println(Runtime.getRuntime().availableProcessors());
    }
}
