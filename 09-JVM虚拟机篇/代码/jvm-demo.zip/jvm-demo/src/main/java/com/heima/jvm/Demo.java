package com.heima.jvm;

public class Demo {

    private static int num1;
    private int num2;

    Demo instance;
    String name;
    public Demo(String name){
        this.name = name;
    }

    
}
